#ifndef _GPIO_MODULE_H
#define _GPIO_MODULE_H

//int gpioInitAll(void);
//void trajectoryCmd();
//int gpiomain();
int gpiomain(const std::string& cmd);



#endif